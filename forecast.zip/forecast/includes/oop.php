<?php

class Registrant
{
    //Objects
    public $username;
    public $firstName;
    public $lastName;
    public $email;
    public $password;

    //Constructors

    public function __construct($username, $firstName, $lastName, $email, $password)
    {
        $this->username = $username;
        $this->firstName = $firstName;
        $this->lastName = $lastName;
        $this->email = $email;
        $this->password = $password;
    }

    // Constructor for signing up
}




// Class of Users which will extend the registration

class Users extends Registrant
{
    public function __construct($username, $firstName, $lastName, $email, $title)
    {
        // Get the constructor attributes
        parent::__construct($username, $firstName, $lastName, $email, $title);
        $this->title = $title;
    }

    // Method to return title

    public function returnTitle()
    {
        return $this-> title;
    }
}

$user = new Users('Kwax', 'Kwanele', 'Khumalo', 'kwax@gmail.com', 'Account Manager');


// echo $user->username;
// echo $user->returnTitle();

// $registrant = new Registrant('Kwax', 'Kwanele', 'Khumalo', 'kwax@gmail.com', '1676');
