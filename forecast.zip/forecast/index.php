<?php
 require './includes/oop.php';
?>
<!DOCTYPE html>
  <html lang="en">
  <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <!--Import Google Icon Font-->
       <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
      <!-- <link rel="stylesheet" href="./css/index.css"> -->
      <link href="./css/index.css? key=<?php echo date('h'); ?>>" type="text/css" rel="stylesheet" />
      <title>Forecasting Platform</title>
  </head>
  <body> 
    <!-- Navbar goes here -->
    <nav class="hide-on-small-only">
      <div class="nav-wrapper">
        <a href="#" class="brand-logo"></a>
        <ul id="nav-mobile" class="right hide-on-small-only">
          <li><a href="#SalesForce">SalesForce</a></li>
          <li><a href="#SalesLoft">SalesLoft</a></li>
          <li><a href="#DocuSign">Admin</a></li>
        </ul>
      </div>
    </nav>
    <!-- Page Layout here-->

  <section class="tab-items">
    
    <ul class="card">
      
    <strong class="center"> <?= 'Hello'.'<br>'. $user->username; ?> </strong>

    <p class="center"> <?= $user->returnTitle(); ?> </p>
      <li><a title="Dashboard" href="#dashboard-tab"><i class="material-icons">dashboard</i></a></li>
      <li><a title="Forecasts" href="#forecast-tab"><i class="material-icons">trending_up</i></a></li>
      <li><a title="Management" href="#management-tab"><i class="material-icons">assessment</i></a></li>
    </ul>

    <!---------------------------------------- Tab-Contents------------------------- -->
   <div class="tab-content">
    <!---------------------------------------- Dashboard------------------------- -->

      <div id="dashboard-tab">
        <h3>Dashboard</h3>
        
        <div class="stats hide-on-small-only">
          <div class="forecast">
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Corrupti, perspiciatis consectetur beatae distinctio officiis fugiat. Iure nesciunt libero consectetur exercitationem quia temporibus error cum veritatis dolorum in deserunt accusantium suscipit animi tenetur ipsum quos reprehenderit sunt dignissimos, et expedita, eos itaque ab. Error quidem corporis necessitatibus ea porro ipsam unde!</p>
          </div>
          <div class="management">
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Corrupti, perspiciatis consectetur beatae distinctio officiis fugiat. Iure nesciunt libero consectetur exercitationem quia temporibus error cum veritatis dolorum in deserunt accusantium suscipit animi tenetur ipsum quos reprehenderit sunt dignissimos, et expedita, eos itaque ab. Error quidem corporis necessitatibus ea porro ipsam unde!</p>
          </div>
        </div>
<!-- Mobile Response -->
        <div class="stats-mobile hide-on-med-and-up">
          <div class="forecast-mobile">
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Illo, consequuntur laudantium quas veniam rem rerum laborum. Beatae voluptatibus soluta omnis, distinctio repellat molestiae est facilis accusamus reiciendis totam nostrum aliquid id odit nemo culpa ratione quae atque harum. Error possimus quaerat at recusandae aspernatur doloribus eos dicta illo totam quos?</p>
          </div>
          <div class="management-mobile">
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Corrupti, perspiciatis consectetur beatae distinctio officiis fugiat. Iure nesciunt libero consectetur exercitationem quia temporibus error cum veritatis dolorum in deserunt accusantium suscipit animi tenetur ipsum quos reprehenderit sunt dignissimos, et expedita, eos itaque ab. Error quidem corporis necessitatibus ea porro ipsam unde!</p>
          </div>
        </div>
      </div>
    <!---------------------------------------- Forecasts------------------------- -->

      <div id="forecast-tab">
        <h3>Forecast</h3>
        <div class="forecast-content center hide-on-small-only">
            <form class="forecast-form"  method="post">
              <div class="input-fields">

                <label for="calendar">Today's Date</label>
                <input type="date" name="date">

                <label for="atr">Total Available to Renew</label>
                <input type="number" name="atr">

                <label for="oncall">Total on call</label>
                <input type="number" name="oncall">

                <label for="actualrenewal">Total Actual Renewals</label>
                <input type="number" name="actualrenewal">
              </div>
              
            </form>
            <a name='forecast-submit' class="center waves-effect waves-light btn">Submit</a>
        </div>

    <!---------------------------------------- Forecasts Mobile------------------------- -->
        <div class="forecast-content hide-on-med-and-up">

        </div>
      </div>
    <!---------------------------------------- Management------------------------- -->

      <div id="management-tab">
        <h3>Management</h3>
        <div class="management-content"></div>
      </div>

   </div>

  </section>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"
  ></script>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
  <script src="https://code.jquery.com/ui/1.13.1/jquery-ui.min.js" integrity="sha256-eTyxS0rkjpLEo16uXTS0uVCS4815lc40K2iVpWDvdSY=" crossorigin="anonymous"></script>
  <script src="./scripts/tabs.js"></script>
  <script src="./scripts/main.js"></script>

  

  </body>
  </html>
