<?php require APPROOT . '/views/inc/head.php';?>
 
<section class="teams">

      <?php require APPROOT . '/views/inc/navbar.php';?>

    
    <section class="main-content">
        <h1 class="meet-team">MEET THE TEAM</h1>
        <div class="team-image">
            <img src="<?= URLPUB ?>/images/team2.jpeg" alt="">
        </div>

        <h1 class="meet-players">MEET THE PLAYERS</h1>

        <div class="the-players">
          <div class="gamer-profile">
                <h5>Gamer Tag:</h5>
                <img style="width:200px ;" src=" <?= URLPUB?>/images/fausto-sandoval-Cc-KUNmV1UE-unsplash.jpg" alt="">
                <strong>Gamer Specialty: Something </strong>
                <strong> Gamer Stats: Something </strong>
          </div>

          <div class="gamer-profile">
                <h5>Gamer Tag:</h5>
                <img style="width:200px ;" src=" <?= URLPUB?>/images/fausto-sandoval-Cc-KUNmV1UE-unsplash.jpg" alt="">
                <strong>Gamer Specialty: Something </strong>
                <strong> Gamer Stats: Something </strong>
          </div>

          <div class="gamer-profile">
                <h5>Gamer Tag:</h5>
                <img style="width:200px ;" src=" <?= URLPUB?>/images/fausto-sandoval-Cc-KUNmV1UE-unsplash.jpg" alt="">
                <strong>Gamer Specialty: Something </strong>
                <strong> Gamer Stats: Something </strong>
          </div>

          <div class="gamer-profile">
                <h5>Gamer Tag:</h5>
                <img style="width:200px ;" src=" <?= URLPUB?>/images/fausto-sandoval-Cc-KUNmV1UE-unsplash.jpg" alt="">
                <strong>Gamer Specialty: Something </strong>
                <strong> Gamer Stats: Something </strong>
          </div>
            
        </div>
    </section>
  </section>
  
  
<?php require APPROOT . '/views/inc/footer.php';?>
