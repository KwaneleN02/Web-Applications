<div class="logo">
    <div class="img">
        <img style="width:200px ;" src="<?= URLPUB ?>/images/eSports-logo-white.png" alt="">
    </div>
    <div class="intro">
        <h1>THE UNIVERSITY OF MONTANA eSPORTS TEAM</h1>
    </div>
 </div>