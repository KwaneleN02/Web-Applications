<header>
    <?php require APPROOT . '/views/inc/navbar.php';?>
    <?php require APPROOT . '/views/inc/logo.php';?>  
</header>