<?php
//Database Parameters
    define('DB_HOST', 'localhost');
    define('DB_USER', 'Kwanele');
    define('DB_PASS', 'Wifeshandi@0207');
    define('DB_NAME', 'eSports');


    //APP Root
    define('APPROOT', dirname(dirname(__FILE__)));

    //URL ROOT
    define('URLROOT', 'http://localhost:8888/Web-Applications/eSports');
    define('URLPUB', 'http://localhost:8888/Web-Applications/eSports/public');

    //SITE NAME
    define('SITENAME', 'Griz eSports');


