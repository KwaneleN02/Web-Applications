<?php
require_once '../App/bootstrap.php';
$core = new Core;
